#include <LiquidCrystal.h>
LiquidCrystal lcd(13, 12, 11, 10, 9, 8);
const int relay = 0;
byte temp;
float t;
int tf;
word lm;
void setup() {
  pinMode(7, INPUT);
  pinMode(6, INPUT);
  pinMode(relay, OUTPUT);
  lcd.begin(16, 2);
}

void loop() {
  boolean up=digitalRead(7);
  if (up==0){
    temp+=1;
    delay(200);
    if (temp==100){
      temp=99;
    }
  }
  boolean dn=digitalRead(6);
  if (dn==0){
    temp-=1;
    delay(200);
    if (temp>=255){
      temp=0;
    }
  }
  lcd.setCursor(0, 1);
  lcd.print("SET T=");
  lcd.setCursor(7, 1);
  lcd.print(temp);
  lm = analogRead(A0);
  t=lm*5;
  t=t/1024;
  t=t*100;
  tf=t;
  lcd.setCursor(0, 0);
  lcd.print("TEMP: ");
  lcd.setCursor(7, 0);
  lcd.print(tf);
  delay(50);
  if (tf>=temp){
    digitalWrite(relay, HIGH);
    lcd.setCursor(10, 1);
    lcd.print("R=ON ");
  }
  if (tf<temp){
    digitalWrite(relay, LOW);
    lcd.setCursor(10, 1);
    lcd.print("R=OFF");
  }
}
